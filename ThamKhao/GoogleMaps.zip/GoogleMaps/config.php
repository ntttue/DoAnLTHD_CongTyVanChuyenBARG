<?php
	$user="root";
	$pswd="vertrigo";
	$db="qnndemo";
	$host="localhost";
?>